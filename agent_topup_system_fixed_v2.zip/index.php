
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Topup</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <h1>ยินดีต้อนรับเข้าสู่ระบบ Agent เติมเครดิต</h1>
    <p>เข้าสู่ระบบด้านล่างเพื่อจัดการ</p>
    <form action="dashboard.php" method="post">
        <label>Username:</label><br>
        <input type="text" name="username"><br>
        <label>Password:</label><br>
        <input type="password" name="password"><br><br>
        <button type="submit">เข้าสู่ระบบ</button>
    </form>
</body>
</html>
