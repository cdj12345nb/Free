BlueStrike.top demo — static site (black/blue theme)
Files:
- index.html
- game_freefire.html
- game_rov.html
- game_pubg.html
- checkout.html
- admin.html
- assets/ (logo + promptpay_qr.png)

How it works (demo):
- User selects game and package, fills phone & UID, clicks "ไปชำระ" → order saved to localStorage and redirected to checkout.
- On checkout user uploads PromptPay slip image and note → order status becomes waiting_for_confirm.
- Admin opens admin.html on same browser/device → sees orders, can view slip and click "ยืนยันเติม" to mark completed.
- This is a client-side demo (no server). To use for real: you'd deploy static files and connect a backend to receive orders, process payments, and let admin confirm in a secure DB.

Deploy:
- You can deploy to Vercel / Netlify as a static site (drag & drop).
- For production you must add a real backend and payment gateway.
