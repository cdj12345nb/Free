function showQR() {
    var uid = document.getElementById('uid').value;
    var pkg = document.getElementById('package').value;

    if (uid.trim() === '') {
        alert('กรุณากรอก UID');
        return;
    }

    document.getElementById('qrSection').style.display = 'block';
    console.log('UID:', uid, 'แพ็กเกจ:', pkg);
}
