function submitTopup() {
  const uid = document.getElementById('uid').value.trim();
  const diamonds = document.getElementById('diamonds').value;
  const status = document.getElementById('status');

  if (uid === '') {
    status.innerHTML = '⚠️ กรุณาใส่ UID ก่อนดำเนินการ';
    status.style.color = 'yellow';
    return;
  }

  status.innerHTML = `⏳ กำลังดำเนินการเติม ${diamonds} เพชรให้กับ UID ${uid} ...`;
  status.style.color = 'lightgreen';

  setTimeout(() => {
    status.innerHTML = `✅ เติมสำเร็จ! ขอบคุณที่ใช้บริการครับ 💎`;
  }, 2000);
}